#pragma once
class square
{
public:
	char fig=' ';
	int color_of_fig=0;
	void set_fig( char figure=' ', int color = 0);
	square();
	~square();
};

