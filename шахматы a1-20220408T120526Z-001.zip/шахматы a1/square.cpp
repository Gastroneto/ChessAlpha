#include "stdafx.h"
#include "square.h"


void square::set_fig( char figure, int color)
{
	fig = figure;
	color_of_fig = color;
}



square::square()
{
}


square::~square()
{
}
