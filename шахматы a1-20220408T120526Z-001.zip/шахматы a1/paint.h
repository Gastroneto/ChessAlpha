#pragma once
#include"square.h"
void paint_pos(square square[][8]);